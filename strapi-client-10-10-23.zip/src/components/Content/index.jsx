import ProductList from "./ProductList";

const Content = ({ platform }) => {
  return (
    <div>
      <ProductList platform={platform} />
    </div>
  );
};
export default Content;
